# Compsoft-technologies-Intership-ProjectReport
    Compsoft technologies-T31
    Project Code-CST2191G6DHN31 

# Name: Deepak D Gowda (1GG19CS012)
        Neha k k (1GG19CS028) 
deepakdgowda3228@gmail.com


# link: https://github.com/Deepak-D-Gowda/internship-project-Quora-for-Engineers.git

                                                 Quora for Engineering Students                                                                                      

# How To Run?

You’ll need XAMP Server or WAMP Server. Put the file inside “c:/xampp/htdocs/”. Go To “http://localhost/phpmyadmin” in any browser and create Database named “quora” .In That Database, Import (db)database quora.sql and finally open go to URL: “http://localhost/Quora/”
    Don’t Forget To create a database and import sql file to run.
    
